import { VNode } from './vnode';
import { DOMAPI } from './htmldomapi';
export declare function toVNode(node: Node, domApi?: DOMAPI): VNode;
export default toVNode;
